# Beyond Storage 3 - Everything Is Your Inventory
I would appreciate it if you could [support me on Ko-fi](https://ko-fi.com/gazorper), as **hundreds of hours** go into making a mod like this, keeping it up to date with newer game versions, not to mention supporting it.

[![Support me on Ko-fi](https://raw.githubusercontent.com/superguru/superguru/refs/heads/master/images/superguru-kofi-orange.png)](https://ko-fi.com/gazorper)

Please go to [![#beyond-storage3](https://img.shields.io/badge/%23beyond--storage3-4c5fd7)](https://discord.gg/hAF5T4P9pE) on [![Discord](https://img.shields.io/badge/%23Discord-f46f30)](https://discord.gg/hAF5T4P9pE) for mod support.

For a quick overview, installation instructions, and troubleshooting, see [QUICK_START.md](https://github.com/superguru/7d2d_mod_BeyondStorage3/blob/master/BeyondStorage/ModPackage/Docs/QUICK_START.md).

## Extended Inventory - Everything Is Your Inventory (aka inventory network)
Items that exist in any of these places are now added to your Backpack and Toolbelt, and become part of your **extended inventory**:
1. Drones
2. Collectors, such as Apiaries, Dew Collectors, Chicken Coops, modded collectors
3. Workstations like Campfire, Forge, Dew Collector, Apiary, Workbench, Chem Station, Cement Mixer, and so on, including community workstations (working ones found in the wild), and modded workstations
4. Containers like crates, and player crafted things like refrigerators, wall safes, lockers, etc. that you crafted and placed. If your ally in a multi-player game crafted it, it's also player crafted storage.
5. Vehicles like Bicycle, 4x4, Minibike, Motorcycle, Gyrocopter, and so on. All modded vehicles also work.

This is the order in which items are Consumed from, too, so Backpack and Toolbelt items are used first, just like in the base game, and after that Drones, then Collectors, etc.

![Player Crafted Wall Safe Inventory Network Toggle](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/network_enable_on_player_wall_safe.jpg)
An example of a player crafted storage, in this case a Wall Safe.

## Consume from the extended inventory
Paint, pick locks, upgrade blocks, refuel equipment and vehicles, repair blocks, pay traders and vending machines, and of course craft things. 

![Consume from Useful Drone](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/consume_from_useful_drone.jpg)

Items from the source slots with the least items are used first.
You can turn off Consume for specific blocks, like for a Wooden Crate or a Locker using the radial menu.
![Enable/Disable Inventory Network radial](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/network_enable_radial_on_off_side_by_side.jpg)

## Smart Push to surrounding storage
You can bulk move all items from any storage to the surrounding storage, providing there is already an item of that type present in that storage.
As long as there are items left to move, the destination slots with the most items will be filled first until all slots across all target storages are filled up to maximum stack size for each item.
Then empty slots will be used, until there is no more space anywhere.

![Smart Push from Campfire](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/smart_push_from_campfire.jpg)

If you use the Smart Push function from this Campfire, then the 6 Bacon and Eggs will be bulk moved to the Wooden Crate that already has other Bacon and Eggs stored in it.
The 16 Water will also be moved to any crates or other player storage if there is already Water in them.
This works from anywhere and anything where you see the Smart Push button.
Yes, Vehicles and Drones too. Also Apiaries and Dew Collectors. Even crates! Everything is included.

### Smart Push Stages (aka Order Of Operations)

1\) Pushing items from anywhere will first try to fill any **Load Out slots (locked slots)** in vehicles and drones, and only afterwards move anything that's left to the surrounding storages.

This should help with keeping your bullets, lock picks, repair kits, and bandages you keep in vehicle or drone **Load Out slots (locked slots)** stocked up without too much other intervention.

2\) After this, any stationary container (that can't move) is tried, and items are sorted into the surrounding Crates, and player created storage per item type they already contain.

Nothing is bulk moved to workstation or collector outputs, because that makes no sense.

3\) Lastly, if there's still something to move, then any mobile storages are tried, also looking for places that already contain the item types that need to be moved, thereby sorting them. Mobile storages are things like vehicles, and drones.

> 👆 Shift Push Mode: There is a stage 4 if you use Shift Push (click the button while holding Shift):
> 4\) After the stages above, any remaining items (that there's room for somewhere) will be moved to any storages that have empty slots, whether or not they already have items of that type.
> - You can Shift Push TO any storages in range
> - You can Shift Push FROM all stationary storages, including workstations.

This helps a lot when you are clearing a POI and you - and perhaps others that you're playing with - placed some dump chests. You can auto-sort items by bulk transferring them using Smart Push, which will fill up those chests, and then also any of your own vehicles and drones nearby that already have any of the remaining items that need to be moved.

### Pushing and Locked Slots
Locking a slot means that you are turning Off any bulk transfers from that slot, just like in the base game. Slot locking prevents items from being bulk moved **OUT**, not in.
So if you always want to keep Wood in your Backpack, lock the slot it's in, and Smart Push will leave it alone.
![Locked Backpack Slots](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/locked_slots_backpack.jpg)
This is my Backpack top row from a current game. None of these items will be bulk moved out of the Backpack, whether using the game *Move All* or *Move and Fill* buttons, or using Smart Push.
The 62 Polymers are not locked, so they can be moved.

### Overflow from Smart Push
**Example 1:** You have 10 Water to push, and there is a Crate that has 9 Water and also an empty slot, then the result after bulk transferring the Water is that the Crate now has a slot with 10 Water and another slot with 9 Water. The extra water overflowed to that Crate's empty slot because it had room.

**Example 2:** You have 10 Water to push, and there are two crates with 2 Water and 3 Water respectively. After the smart push, the two crates will have 10 Water and 5 Water respectively.

**Example 3:** You have 20 Water to push, and there are two crates.
- Crate A has 2 Water, 1 empty slot. 
- Crate B has 3 Water, 1 empty slot.

After the smart push:
- Crate A has 10 Water, 5 Water <- 8 Water came in, filling the 2 Water slot, then 5 was left to put in the empty slot
- Crate B has 10 Water, 1 empty slot <- 7 Water came in, and filled up the existing 3 Water slot

📢**Note:** These examples are for the default max stack size of 10 Water in Vanilla default settings. You can change the stack size in the Sandbox Options, which will have the same logic, just with different max stack sizes for items.

## Smart Pull, aka Topping up your Load Out
If you lock some slots in your Backpack (Player Inventory), or in Drones, vehicles like Motorcycle, Gyrocopter, and so on, then you can use those as your **Load Out** slots.
Using the Smart Pull button will top up any items in those slots with any available items.
![Smart Pull Loadout to Bicycle](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/smart_pull_bicycle_loadout.jpg)
This is my trusty Bicycle. I always keep Coins, Repair Kits, Lock picks, Shotgun Ammo, and Arrows in there.
I never keep any of these items in my own inventory, so my Backpack is just for looted items and whatnot.
Before leaving the base, I just use Smart Pull to Top Up my Bicycle Load Out, and I have a fresh load of bullets and other needful things to go **On Mission**.

I also do a Smart Push from the Workbench to sort any produced ammo to storages in the following order:
1. My Bicycle (or any vehicles or drones that belong to me, closest first) - top up the **Load Out slots (locked slots)**
2. Stationary storage - Crates, player crafted storage, etc. with items matching the ones being transferred
3. Mobile storage - vehicles and drones again, but this time not limited to locked slots, but any slot that already contains the items being transferred

### Gotchas about Smart Pull
Items are only pulled from stationary storages like crates and other user created and placed containers. Never from vehicles or drones.
So <span style="color:#ff2222;">**you can't pull in**</span> ammo from your Bicycle into your Drone, for instance.
Pulling in items will not overflow to empty slots, whether they're locked or not. All it does is fill up a slot with an existing item until the maximum stack size for that item is reached.
![Player Crafted Office Desk Example](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/player_crafted_office_desk_example.jpg)
This is my office desk that I **crafted and placed myself**. It is also part of the extended inventory network. The same Wall Safe from the earlier example is just above it.

## 🩹 Useables: Use directly from your Extended Inventory
Next to your Backpack, you'll see a small **Useables** window with 6 slots, showing the best healing, food, and drink items currently available in your **Extended Inventory** (nearby storage, vehicles, drones, etc.) — not your Backpack, since those items are already right there next to it.

It only appears when your Backpack is open by itself — it's hidden while a vehicle, workstation, trader, drone, character screen, or other container window is also open, so it never gets in the way.

![Useables window](https://raw.githubusercontent.com/superguru/7d2d_mod_BeyondStorage3/refs/heads/master/BeyondStorage/Media/useables_window.jpg)

- **Top row:** your best healing item — matched to how much health you're missing — plus up to 2 items that cure a condition you currently have (bleeding, infection, and so on). Leftover slots fill with more available healing items, if you need healing.
- **Bottom row:** up to 1 best food item and 2 best drinks, ranked by nutrition, then health, then bonus buffs. If you have no drinks, the gap fills with more food instead (and the other way around).

An item with a health penalty (like Rotting Flesh) will always rank below a "clean" item of the same kind, even if you have a lot more of it.

To use an item shown in the Useables window:
- Press the number key (1-6) shown in the corner of its slot, or
- Double-click the item's icon.

A single click on a slot shows the same item info panel you'd see for a normal Backpack or Toolbelt item, without using it.

The Useables window refreshes automatically whenever any inventory in the game changes (items added, removed, or moved between slots) and when the mod's internal storage cache expires, so the row always reflects what is currently available.

## Multiplayer Explained
Firstly, it's important to understand that no one player owns anything **except** Vehicles or Drones in the game.

So if you build a Crate and place it, then anyone of your Allies can access it. If you build a Wall Safe and place it, then the same rule applies.

When you read this documentation you will see it mentions "Player crafted storage", and it's important to understand this concept.

- Did you craft the Wooden Crate? Then that's a "Player crafted storage".
- Did your friend who is multiplaying with you and is an Ally craft the Wooden Crate? Then that's also a "Player crafted storage".

📢 Just because you personally crafted and placed a Wooden Crate, does not mean you own that crate. No-one owns it.

You can run over to your friend's base, or to a crate that they built and placed, and just open it and take what's inside, or perhaps put some items into the crate.

All of these storages are part of your, and any of your Allies', extended inventory, providing it's in **range**.

### What about land claims?
Placing a Land Claim Block does not mean you claim **ownership** over anything.

This is just how the game works.

Zombies don't spawn in range of a Land Claim Block, unless it's a Blood Moon.

Enemies - players who are not Allies - don't spawn there at any time.

Also, Land Claim Blocks prevent enemy damage to your Ally group's blocks.

### So what can you do to prevent your friend from using items in "your" storage?
1. Do not ally with that player. Allies **share everything** except Vehicles and Drones.
2. Move the storage out of range of your Ally. But if your friend runs over to your storage, they would come in range of it, and then be able to use the items inside. This is just a sort of general suggestion.
3. You can Disable a storage from the Inventory Network. This removes it from the extended inventory entirely, so no-one — including yourself — can Consume from it, or Smart Push or Pull to and from it.

### Locking your storage
You can lock your storage **with a PIN**. Then only someone with the PIN can open the storage physically, and the same goes for their extended inventory.

So lock it **with a PIN**, don't share the PIN, and then only you can Consume from it, and only you can Smart Push and Pull to and from it.

### Short Summary about Multiplayer storage
In this game, there is no concept whatsoever of a particular Player owning a Crate or any other storage.

A Player can only own a Vehicle or a Drone.

## Console and Config

### Console Commands (when you press F1)

```text
+----------------+--------------------------------------------------------------+
| Command        | Description                                                  |
+----------------+--------------------------------------------------------------+
| bshelp         | List available commands with their descriptions              |
+----------------+--------------------------------------------------------------+
| bsclearcache   | Invalidates cache and reloads items from storages            |
+----------------+--------------------------------------------------------------+
| bsreloadconfig | Reload the config as per the current modconfig.json file     |
|                | (maybe you modified it in a text editor)                     |
+----------------+--------------------------------------------------------------+
| bssetconfig    | Change the value of a config property                        |
+----------------+--------------------------------------------------------------+
| bsshowconfig   | Displays the current active config settings                  |
+----------------+--------------------------------------------------------------+
```

### Config file
The mod can also be configured by editing `Mods/BeyondStorage3/modconfig.json`

```text
+---------------------------+---------+------------------------------------------------------------+
| Setting                   | Default | Description                                                |
+---------------------------+---------+------------------------------------------------------------+
| includeDrones             | On      | Whether to include nearby Drones in storage network        |
+---------------------------+---------+------------------------------------------------------------+
| includeVehicles           | On      | Whether to include nearby Vehicles in storage network      |
+---------------------------+---------+------------------------------------------------------------+
| allowPushToAlliedVehicles | On      | Allow smart push to send items to nearby Vehicles          |
|                           |         | belonging to allies                                        |
|                           |         | Only works if includeVehicles is On                        |
+---------------------------+---------+------------------------------------------------------------+
| showUseables              | On      | Enables the Useables window if Backpack is open on its own |
+---------------------------+---------+------------------------------------------------------------+
| isDebug                   | Off     | Logs additional information that might be useful for       |
|                           |         | troubleshooting problems. You can generally leave this     |
|                           |         | turned off.                                                |
+---------------------------+---------+------------------------------------------------------------+
| range                     | 0.0     | Range to include in storage network.                       |
|                           |         | 0.0 is everything in memory, max is 250m.                  |
|                           |         | The game usually holds up to 200m radius.                  |
+---------------------------+---------+------------------------------------------------------------+
*Off=false, On=True in modconfig.json file.
```

** [Gears](https://www.nexusmods.com/7daystodie/mods/4017) settings support ** (Optional)
All settings can be modified using the Gears interface.
This is available at the game loading screen, and also in-game when you press \<ESC\> and click the \[MODS\] button.

`Mods/BeyondStorage3/modconfig.json` is the master source for config values, and changes to this file will override the settings saved in Gears. However Gears settings will always be synced when you access the Gears settings editing screen.

*Any setting not listed here is either old, or otherwise is for mod development purposes. It's best to leave them alone.*
*The mod will automatically convert older properties and values, removing invalid ones as needed, when it loads.*

#### Notes:
1. In the config file, true means On and false means Off
2. Previous versions of the mod had other config options. Their usage was self-explanatory from their names.

## License

This mod is licensed under the [Apache-2.0 License](https://www.apache.org/licenses/LICENSE-2.0.html). See the [LICENSE.txt](https://github.com/superguru/7d2d_mod_BeyondStorage3/blob/master/LICENSE.txt) for details.

## History

[Undead Legacy](https://www.snowbeegaming.com/undead-legacy) by Subquake was almost certainly the first mod to introduce the "remote broadcasting" of items for crafting, as if you had a gigantic inventory that included your storage crates.

[Craft From Containers](https://www.nexusmods.com/7daystodie/mods/2196?tab=description) by aedenthorn implemented this for later versions of the game, as Undead Legacy was not available for post A21 at the time. The source code is on [GitHub](https://github.com/aedenthorn/7D2DMods)

[1.0 Beyond Storage](https://www.nexusmods.com/7daystodie/mods/5087) was refactored and updated for 7 Days to Die v1 by unv-annihilator and extended this idea, based on the code from aedenthorn. This brought the addition of vehicles to pull items from. The code quality and stability of this mod is high. See [https://github.com/unv-annihilator/7D2D_Mods/tree/main](https://github.com/unv-annihilator/7D2D_Mods/tree/main) for that fork.

[Beyond Storage 2](https://github.com/superguru/7d2d_mod_BeyondStorage2) added pulling from all conceivable sources, like drones, workstation outputs, dew collectors. Also added all inventory operations like paying for items at a trader, painting, lock picking. The mod also fixes many notification bugs from the original game, and all operations are seamless. Pushing items from any place you can pull from, in order to auto-sort items, was also added.

*** PACKAGED aka MOD DOCUMENTATION PAGE README.md EOF ***
