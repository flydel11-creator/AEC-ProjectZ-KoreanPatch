﻿@echo off
chcp 65001 >nul
setlocal
title Ducksfly 7DTD 모드 업데이트
set "MODS=%~dp0"
set "BASE=https://raw.githubusercontent.com/flydel11-creator/AEC-ProjectZ-KoreanPatch/main"
set "TMP=%TEMP%\ducksfly_pack"

echo.
echo  =====================================================
echo   Ducksfly 서버 모드 업데이트
echo  =====================================================
echo   설치 위치: %MODS%
echo.

if not exist "%MODS%99-KoreanPatch" if not exist "%MODS%BeyondStorage3" (
  echo  [주의] 이 파일은 게임의 Mods 폴더 안에 두고 실행해야 합니다.
  echo         예: C:\Program Files ^(x86^)\Steam\steamapps\common\7 Days To Die\Mods\
  echo.
  pause
  exit /b 1
)

if not exist "%TMP%" mkdir "%TMP%" >nul 2>&1
del /q "%TMP%\ver.txt" >nul 2>&1

echo  [1/4] 최신 버전 확인 중...
powershell -NoProfile -Command "try{ (New-Object Net.WebClient).DownloadFile('%BASE%/pack_version.txt','%TMP%\ver.txt') ; exit 0 } catch { exit 1 }"
if not exist "%TMP%\ver.txt" (
  echo  [실패] 인터넷에서 버전 정보를 못 받았습니다. 잠시 후 다시 시도하세요.
  echo.
  pause
  exit /b 1
)

set "NEWVER="
set /p NEWVER=<"%TMP%\ver.txt"
set "OLDVER=없음"
if exist "%MODS%_pack_version.txt" set /p OLDVER=<"%MODS%_pack_version.txt"

echo         설치된 버전: %OLDVER%
echo         최신 버전  : %NEWVER%

if "%OLDVER%"=="%NEWVER%" (
  echo.
  echo  이미 최신입니다. 할 일이 없습니다.
  echo.
  timeout /t 5 >nul
  exit /b 0
)

echo.
echo  [2/4] 새 파일 내려받는 중... ^(약 1MB^)
del /q "%TMP%\pack.zip" >nul 2>&1
powershell -NoProfile -Command "try{ (New-Object Net.WebClient).DownloadFile('%BASE%/Ducksfly_ServerPack_v1_for_3.2.zip','%TMP%\pack.zip') ; exit 0 } catch { exit 1 }"
if not exist "%TMP%\pack.zip" (
  echo  [실패] 내려받기에 실패했습니다.
  echo.
  pause
  exit /b 1
)

echo  [3/4] 압축 푸는 중...
powershell -NoProfile -Command "try{ Expand-Archive -LiteralPath '%TMP%\pack.zip' -DestinationPath '%MODS%.' -Force ; exit 0 } catch { Write-Host $_.Exception.Message ; exit 1 }"
if errorlevel 1 (
  echo  [실패] 압축 풀기에 실패했습니다. 게임이 켜져 있으면 끄고 다시 해보세요.
  echo.
  pause
  exit /b 1
)

echo  [4/4] 마무리...
copy /y "%TMP%\ver.txt" "%MODS%_pack_version.txt" >nul
del /q "%TMP%\pack.zip" >nul 2>&1

echo.
echo  =====================================================
echo   업데이트 완료  ^(%NEWVER%^)
echo  =====================================================
echo   게임은 EAC 를 끄고 실행하세요.
echo   Play 7 Days to Die ^(No EAC^)
echo.
timeout /t 8 >nul
exit /b 0
