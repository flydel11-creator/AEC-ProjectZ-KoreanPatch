@echo off
setlocal
REM ==========================================================
REM  AEC x Project Z Korean Patch - auto setup
REM  Run this file from inside the game's (or server's) Mods folder.
REM  It enables the Korean files that already ship inside the pack.
REM ==========================================================
cd /d "%~dp0"

if not exist "01-ProjectZ\Config" (
  echo [ERROR] 01-ProjectZ folder not found. Put this .bat inside the Mods folder and run again.
  pause & exit /b 1
)
if not exist "99-KoreanPatch\ModInfo.xml" (
  echo [WARN] 99-KoreanPatch not found next to this file. Copy the 99-KoreanPatch folder into Mods first.
)

echo.
echo [1/2] ProjectZ language file -^> Korean
if exist "01-ProjectZ\MultiLanguage\Localization.Eng.Koreana.csv" (
  if not exist "01-ProjectZ\Config\Localization.csv.rus_backup" (
    if exist "01-ProjectZ\Config\Localization.csv" copy /y "01-ProjectZ\Config\Localization.csv" "01-ProjectZ\Config\Localization.csv.rus_backup" >nul
  )
  copy /y "01-ProjectZ\MultiLanguage\Localization.Eng.Koreana.csv" "01-ProjectZ\Config\Localization.csv" >nul
  echo       done
) else (
  echo       [SKIP] Localization.Eng.Koreana.csv not found
)

echo [2/2] AEC event / nemesis JSON -^> koreana
for %%F in ("04-AEC-ENDGAME_OVERHAUL\AeclipseNemesisLocalization.json" "04-AEC-ENDGAME_OVERHAUL\AeclipseEventsLocalization.json") do (
  if exist %%F (
    if not exist "%%~F.eng_backup" copy /y %%F "%%~F.eng_backup" >nul
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%%~F'; $t=[IO.File]::ReadAllText($p,[Text.Encoding]::UTF8); $t=[regex]::Replace($t,'\"language\"\s*:\s*\"[a-z]+\"','\"language\": \"koreana\"',1); [IO.File]::WriteAllText($p,$t,(New-Object Text.UTF8Encoding($false)))"
    echo       %%~nxF done
  ) else (
    echo       [SKIP] %%~nxF not found
  )
)

echo.
echo All done. Start the game with language set to Korean.
echo (To undo: rename the *_backup files back to their original names and delete 99-KoreanPatch.)
pause
