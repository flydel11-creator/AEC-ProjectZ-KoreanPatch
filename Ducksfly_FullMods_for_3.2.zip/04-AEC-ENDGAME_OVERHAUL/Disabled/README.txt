AEC ENDGAME OVERHAUL — canonical disabled/rollback notes (Project Z + AEC v9.23.0)

AeclipseCustomZombieForestSafe.dll remains DISABLED in this folder. Forest/LowGS protection is owned by the canonical spawn-rule integration; do not move ForestSafe to the mod root unless that policy is intentionally changed and quest behavior is retested.

AeclipseCustomZombieHeadRewards.dll is the upstream 3.1.3 binary and remains DISABLED because kill rewards are owned by the canonical Mutation Samples + Infected Teeth + Zombie Corpse system.

AeclipseCustomZombieEvents.dll is intentionally absent. AEC world events remain active through AIMaster/event AI modules/Heatmap; the removed legacy Events DLL is not required by upstream 3.1.3.
